import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p className="text-center">
  From  <a href="http://pro.eattheblocks.com" style={{color: 'white'}}>6-Figures Blockchain dev</a>, a Blockchain course to become a Profesional Blockchain developer
      </p>
    </footer>
  );
};

export default Footer;
